#!/bin/bash
#SBATCH --job-name=pythia_dr
#SBATCH --output=logs/%x-%j.out
#SBATCH -e logs/%x-%j.err
#SBATCH --gres=gpu:nvidia_a100-pcie-40gb:1 
#SBATCH --cpus-per-task=4
#SBATCH --mem=100G

eval "$(conda shell.bash hook)"
conda activate cmu-llms-hw3

model_to_train=jmvcoelho/pythia-160m-1024-marco-docs-bow-contrastive-pretrain

trained_model_save_path=$1
mkdir -p $1

trained_model_name=pythia-160m-1024-marco-docs-bow-contrastive-pretrain-marco-passage-sft
training_data=Tevatron/msmarco-passage-aug

python -m driver.train \
  --output_dir $1/$trained_model_name \
  --model_name_or_path $model_to_train \
  --dataset_name $training_data \
  --save_steps 0 \
  --bf16 \
  --gradient_checkpointing \
  --temperature 0.01 \
  --per_device_train_batch_size 128 \
  --train_group_size 10 \
  --learning_rate 1e-4 \
  --query_max_len 32 \
  --passage_max_len 128 \
  --num_train_epochs 1 \
  --logging_steps 1 \
  --overwrite_output_dir \
  --gradient_accumulation_steps 2 \
  --report_to wandb \
  --run_name $trained_model_name
