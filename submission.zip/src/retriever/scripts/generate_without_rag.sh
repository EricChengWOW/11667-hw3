#!/bin/bash
#SBATCH --job-name=pythia_dr
#SBATCH --output=logs/%x-%j.out
#SBATCH -e logs/%x-%j.err
#SBATCH --gres=gpu:nvidia_a100-pcie-40gb:1 
#SBATCH --cpus-per-task=4
#SBATCH --mem=100G

eval "$(conda shell.bash hook)"
conda activate cmu-llms-hw3

python -m driver.rag \
  --prefixes ./data/prefixes.jsonl \
  --output_dir ./data/
