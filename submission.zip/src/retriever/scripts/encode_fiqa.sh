#!/bin/bash
#SBATCH --job-name=pythia_dr
#SBATCH --output=logs/%x-%j.out
#SBATCH -e logs/%x-%j.err
#SBATCH --gres=gpu:nvidia_a100-pcie-40gb:1 
#SBATCH --cpus-per-task=4
#SBATCH --mem=100G

mkdir logs

export TRANSFORMERS_CACHE=/data/datasets/hf_cache

eval "$(conda shell.bash hook)"
conda activate cmu-llms-hw3

module load cuda-11.8


test_data=fiqa
EMBEDDING_OUTPUT_DIR=$1/$trained_model_name/$test_data

trained_model_name=pythia-160m-1024-marco-docs-bow-contrastive-pretrain-marco-passage-sft
trained_model_path=$2/$trained_model_name



mkdir -p $EMBEDDING_OUTPUT_DIR

python -m driver.encode \
  --output_dir=temp \
  --model_name_or_path $trained_model_path \
  --bf16 \
  --encode_is_query \
  --per_device_eval_batch_size 128 \
  --query_max_len 32 \
  --passage_max_len 128 \
  --dataset_name Tevatron/beir \
  --dataset_config $test_data \
  --dataset_split test \
  --encode_output_path $EMBEDDING_OUTPUT_DIR/query-test.pkl

python -m driver.encode \
  --output_dir=temp \
  --model_name_or_path $trained_model_path \
  --bf16 \
  --per_device_eval_batch_size 128 \
  --query_max_len 32 \
  --passage_max_len 128 \
  --dataset_name Tevatron/beir-corpus \
  --dataset_config $test_data \
  --dataset_number_of_shards 1 \
  --encode_output_path $EMBEDDING_OUTPUT_DIR/corpus.pkl

