from dataclasses import dataclass
from typing import Dict, Optional

import torch
from torch import nn, Tensor
import torch.nn.functional as F

from transformers import PreTrainedModel, AutoModel

from transformers.file_utils import ModelOutput
from retriever.arguments import ModelArguments, TevatronTrainingArguments as TrainingArguments

import logging
logger = logging.getLogger(__name__)


@dataclass
class EncoderOutput(ModelOutput):
    q_reps: Optional[Tensor] = None
    p_reps: Optional[Tensor] = None
    loss: Optional[Tensor] = None
    scores: Optional[Tensor] = None


class EncoderModel(nn.Module):
    TRANSFORMER_CLS = AutoModel

    def __init__(self,
                 encoder: PreTrainedModel,
                 temperature: float = 1.0,
                 ):
        super().__init__()
        self.config = encoder.config
        self.encoder = encoder
        self.temperature = temperature

    def forward(self, query: Dict[str, Tensor] = None, passage: Dict[str, Tensor] = None):
        q_reps = self.encode_text(query) if query else None
        p_reps = self.encode_text(passage) if passage else None

        # for inference
        if q_reps is None or p_reps is None:
            return EncoderOutput(
                q_reps=q_reps,
                p_reps=p_reps
            )

        scores = self.compute_similarity(q_reps, p_reps, self.temperature)
        target = self.compute_labels(q_reps.size(0), p_reps.size(0)).to(scores.device)
        loss = self.compute_loss(scores, target)

        return EncoderOutput(
            loss=loss,
            scores=scores,
            q_reps=q_reps,
            p_reps=p_reps,
        )
    
    def pooling(self, last_hidden_state, attention_mask):
        # last-token pooling with right-padding 
        sequence_lengths = attention_mask.sum(dim=1) - 1
        batch_size = last_hidden_state.shape[0]
        reps = last_hidden_state[torch.arange(batch_size, device=last_hidden_state.device), sequence_lengths]
        reps = torch.nn.functional.normalize(reps, p=2, dim=-1)
        return reps

    def encode_text(self, text):
        hidden_states = self.encoder(**text, return_dict=True)
        hidden_states = hidden_states.last_hidden_state
        return self.pooling(hidden_states, text['attention_mask'])

    def compute_similarity(self, q_reps, p_reps, temperature):
        return torch.matmul(q_reps, p_reps.transpose(0, 1)) / temperature

    def compute_labels(self, n_queries, n_passages):
        target = torch.arange(n_queries, dtype=torch.long)
        target = target * (n_passages // n_queries)
        return target
    
    def compute_loss(self, scores, target):
        return F.cross_entropy(scores, target, reduction='mean')

    def gradient_checkpointing_enable(self, **kwargs):
        try:
            self.encoder.model.gradient_checkpointing_enable()
        except Exception:
            self.encoder.gradient_checkpointing_enable()



            

    @classmethod
    def build(
            cls,
            model_args: ModelArguments,
            train_args: TrainingArguments,
            **hf_kwargs,
    ):  
        base_model = cls.TRANSFORMER_CLS.from_pretrained(model_args.model_name_or_path, **hf_kwargs)
        if base_model.config.pad_token_id is None:
            base_model.config.pad_token_id = 0
        
        model = cls(
            encoder=base_model,
            temperature=model_args.temperature
        )
        return model

    @classmethod
    def load(cls,
             model_name_or_path: str,
             **hf_kwargs):
        base_model = cls.TRANSFORMER_CLS.from_pretrained(model_name_or_path, **hf_kwargs)

        if base_model.config.pad_token_id is None:
            base_model.config.pad_token_id = 0

        model = cls(
            encoder=base_model,
        )
        return model

    def save(self, output_dir: str):
        self.encoder.save_pretrained(output_dir)